In questo zip sono contenuti:
-La relazione in formato PDF
-I notebook per tutti i modelli che sono stati eseguiti in locale
-I notebook del Neural Language Model sono stati eseguiti su Google Colab e si trovano nell'apposita cartella
-I testi preprocessati per l'elaborazione
-I testi elaborati con ProfilingUD
-I grafici delle elaborazioni in formato SVG

Per eseguire i notebook è necessario scaricare gli Embeddings (sia itWac che Twitter) che non includo per motivi di memoria occupata.